﻿ergebnis ausführen, octave 4.0.2 wurde benutzt.
